﻿namespace PAluno02
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Execute = new Button();
            Clean = new Button();
            SuspendLayout();
            // 
            // Execute
            // 
            Execute.Location = new Point(224, 33);
            Execute.Name = "Execute";
            Execute.Size = new Size(183, 144);
            Execute.TabIndex = 0;
            Execute.Text = "Executar";
            Execute.UseVisualStyleBackColor = true;
            Execute.Click += Execute_Click;
            // 
            // Clean
            // 
            Clean.Location = new Point(224, 250);
            Clean.Name = "Clean";
            Clean.Size = new Size(183, 140);
            Clean.TabIndex = 1;
            Clean.Text = "Limpar";
            Clean.UseVisualStyleBackColor = true;
            Clean.Click += Clean_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Clean);
            Controls.Add(Execute);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button Execute;
        private Button Clean;
    }
}
