using Microsoft.VisualBasic;
using System.Collections;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        string auxiliar = "";
        double[,] NotasAlunos = new double[3, 2];
        double mediaIndividual, mediaGeral;
        int i, j;
        public Form1()
        {
            InitializeComponent();
        }

        private void Execute_Click(object sender, EventArgs e)
        {
            auxiliar = Interaction.InputBox($"Professor {j + 1}, insira a nota do aluno {i + 1}");
                    if (!double.TryParse(auxiliar, out NotasAlunos[j,i]))
                    {
                        MessageBox.Show("Insira dados v�lidos!");
                    }
                    else
                    {
                        for (j=0;j<3;j++)
                        {

                         for (i=0;i<2;i++)
                           {       
                             auxiliar = Interaction.InputBox($"Professor {j + 1}, insira a nota do aluno {i + 1}");
                             MessageBox.Show($"Aluno {i+1}, sua nota do professor {j+1} �: " + NotasAlunos[j, i]);
                             mediaIndividual += NotasAlunos[j, i] / 3;

                           }

                        }
            }
            mediaGeral = mediaIndividual / 2;
            MessageBox.Show($"Media indivual do aluno {i}: " + mediaIndividual);
            MessageBox.Show("Media Geral dos alunos: " + mediaGeral);

        }

        private void Clean_Click(object sender, EventArgs e)
        {
            mediaGeral = 0;
            mediaIndividual = 0;

        }
    }
}
